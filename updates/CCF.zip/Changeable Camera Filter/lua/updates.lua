if UpdateThisMod then
	UpdateThisMod:Add({
		mod_id = 'Changeable Camera Filter',
		data = {
			modworkshop_id = 22650,
			dl_url = "https://github.com/PJzuza/Changeable-Camera-Filter/raw/master/updates/CCF.zip",
			info_url = "https://raw.githubusercontent.com/PJzuza/Changeable-Camera-Filter/master/mod.txt"
		}
	})
end